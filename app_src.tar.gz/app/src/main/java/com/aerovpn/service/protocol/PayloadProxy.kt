package com.aerovpn.service.protocol

import com.jcraft.jsch.Proxy
import com.jcraft.jsch.SocketFactory
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Sends a user payload before JSch starts the SSH protocol. This intentionally does
 * not rewrite or forge SSH data; it only expands HTTP Custom [crlf] tokens. */
internal class PayloadProxy(private val rawPayload: String) : Proxy {
    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    override fun connect(factory: SocketFactory?, host: String?, port: Int, timeout: Int) {
        val s = if (factory != null) factory.createSocket(host, port) else Socket()
        if (!s.isConnected) s.connect(InetSocketAddress(host, port), timeout)
        socket = s; input = s.getInputStream(); output = s.getOutputStream()
        val payload = rawPayload.replace("[crlf]", "\r\n").replace("[lf]", "\n")
        output!!.write(payload.toByteArray(Charsets.UTF_8)); output!!.flush()
    }
    override fun getInputStream(): InputStream = input ?: error("proxy not connected")
    override fun getOutputStream(): OutputStream = output ?: error("proxy not connected")
    override fun getSocket(): Socket = socket ?: error("proxy not connected")
    override fun close() { try { socket?.close() } finally { socket=null; input=null; output=null } }
}
