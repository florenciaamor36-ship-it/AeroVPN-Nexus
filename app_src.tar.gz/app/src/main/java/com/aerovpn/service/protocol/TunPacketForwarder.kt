package com.aerovpn.service.protocol

import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.FileInputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Owns the Android TUN read loop. This is deliberately a packet boundary: an
 * SSH channel is a byte stream and cannot carry arbitrary IP packets without a
 * TCP/UDP user-space stack. Keeping that conversion out of SSHProtocol avoids
 * silently corrupting traffic or advertising a fake VPN.
 */
internal class TunPacketForwarder(
    private val tun: ParcelFileDescriptor,
    private val executor: ExecutorService,
    private val onPacket: (ByteArray, Int) -> Unit
) {
    companion object { private const val TAG = "TunPacketForwarder" }

    private val stopped = AtomicBoolean(false)
    private val packets = AtomicLong(0)
    private val bytes = AtomicLong(0)
    private val unsupported = AtomicLong(0)

    fun start() {
        executor.execute {
            val buffer = ByteArray(32767)
            try {
                FileInputStream(tun.fileDescriptor).use { input ->
                    while (!stopped.get()) {
                        val length = input.read(buffer)
                        if (length <= 0) break
                        packets.incrementAndGet()
                        bytes.addAndGet(length.toLong())
                        val version = (buffer[0].toInt() ushr 4) and 0x0f
                        if (version != 4 || length < 20) {
                            unsupported.incrementAndGet()
                            continue
                        }
                        val headerLength = (buffer[0].toInt() and 0x0f) * 4
                        if (headerLength < 20 || headerLength > length) {
                            unsupported.incrementAndGet()
                            continue
                        }
                        val protocol = buffer[9].toInt() and 0xff
                        // The transport adapter is intentionally explicit: no packet is
                        // written back until a real IP/TCP or IP/UDP implementation exists.
                        onPacket(buffer.copyOf(length), protocol)
                    }
                }
            } catch (e: Exception) {
                if (!stopped.get()) Log.w(TAG, "TUN read loop stopped", e)
            }
        }
    }

    fun stop() { stopped.set(true) }
    fun packetCount(): Long = packets.get()
    fun byteCount(): Long = bytes.get()
    fun unsupportedCount(): Long = unsupported.get()
}
