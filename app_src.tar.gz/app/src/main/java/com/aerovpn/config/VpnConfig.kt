package com.aerovpn.config

import java.io.Serializable
import java.util.UUID

/**
 * Unified VPN configuration model used across export/import and UI layers.
 */
data class VpnConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val protocol: String,
    val host: String = "",
    val port: Int = 0,
    val username: String? = null,
    val password: String? = null,
    /** PEM/OpenSSH private key. Kept separate from password for round-trip imports. */
    val privateKey: String? = null,
    val privateKeyPassphrase: String? = null,
    /** HTTP Custom-compatible payload sent before/around the tunnel handshake. */
    val payload: String? = null,
    val proxyHost: String? = null,
    val proxyPort: Int? = null,
    /** Supported values are NONE, HTTP, HTTPS and SOCKS5. */
    val proxyType: String = "NONE",
    val sni: String? = null,
    val tlsEnabled: Boolean = false,
    val tlsInsecure: Boolean = false,
    val configData: String? = null,
    val method: String? = null,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false,
    val lastUsed: String = "",
    // Legacy/compat field
    val server: String = host
) : Serializable
