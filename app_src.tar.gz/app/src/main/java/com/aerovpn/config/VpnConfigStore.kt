package com.aerovpn.config
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
/** Local persistence for profiles. Credentials remain in app-private storage. */
object VpnConfigStore {
 private const val PREFS="vpn_profiles"; private const val KEY="profiles"
 fun load(c:Context):List<VpnConfig> = runCatching { val a=JSONArray(c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(KEY,"[]")); (0 until a.length()).map{fromJson(a.getJSONObject(it))} }.getOrDefault(emptyList())
 fun save(c:Context, cs:List<VpnConfig>){val a=JSONArray();cs.forEach{a.put(toJson(it))};c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply()}
 private fun JSONObject.putN(k:String,v:String?){put(k,v?:JSONObject.NULL)}
 private fun JSONObject.getN(k:String)=if(isNull(k))null else optString(k).ifEmpty{null}
 private fun toJson(c:VpnConfig)=JSONObject().apply{put("id",c.id);put("name",c.name);put("protocol",c.protocol);put("host",c.host);put("port",c.port);putN("username",c.username);putN("password",c.password);putN("privateKey",c.privateKey);putN("privateKeyPassphrase",c.privateKeyPassphrase);putN("payload",c.payload);putN("proxyHost",c.proxyHost);c.proxyPort?.let{put("proxyPort",it)};put("proxyType",c.proxyType);putN("sni",c.sni);put("tlsEnabled",c.tlsEnabled);put("tlsInsecure",c.tlsInsecure);putN("configData",c.configData);putN("method",c.method);putN("notes",c.notes);put("createdAt",c.createdAt);put("isFavorite",c.isFavorite);put("lastUsed",c.lastUsed)}
 private fun fromJson(j:JSONObject)=VpnConfig(id=j.optString("id"),name=j.optString("name","Imported Config"),protocol=j.optString("protocol","custom"),host=j.optString("host"),port=j.optInt("port"),username=j.getN("username"),password=j.getN("password"),privateKey=j.getN("privateKey"),privateKeyPassphrase=j.getN("privateKeyPassphrase"),payload=j.getN("payload"),proxyHost=j.getN("proxyHost"),proxyPort=if(j.has("proxyPort"))j.optInt("proxyPort")else null,proxyType=j.optString("proxyType","NONE"),sni=j.getN("sni"),tlsEnabled=j.optBoolean("tlsEnabled"),tlsInsecure=j.optBoolean("tlsInsecure"),configData=j.getN("configData"),method=j.getN("method"),notes=j.getN("notes"),createdAt=j.optLong("createdAt"),isFavorite=j.optBoolean("isFavorite"),lastUsed=j.optString("lastUsed"))
}
