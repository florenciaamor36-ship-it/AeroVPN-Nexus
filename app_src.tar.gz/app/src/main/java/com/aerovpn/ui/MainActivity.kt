package com.aerovpn.ui

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aerovpn.config.VpnConfig
import com.aerovpn.config.VpnConfigStore
import com.aerovpn.service.AeroVpnService
import com.aerovpn.service.protocol.SSHConfig
import com.aerovpn.ui.theme.AeroVPNTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(state: Bundle?) { super.onCreate(state); setContent { AeroVPNTheme { ConfigApp() } } }
    @Composable private fun ConfigApp() {
        var configs by remember { mutableStateOf(VpnConfigStore.load(this)) }
        var editing by remember { mutableStateOf<VpnConfig?>(null) }
        if (editing != null) {
            SshEditor(editing!!, onCancel={editing=null}, onSave={ c ->
                configs = (configs.filterNot { it.id == c.id } + c); VpnConfigStore.save(this, configs); editing=null
            }, onConnect={ c ->
                VpnConfigStore.save(this, configs); val i=VpnService.prepare(this)
                if (i != null) startActivityForResult(i, 41) else startService(Intent(this, AeroVpnService::class.java).apply { action=AeroVpnService.ACTION_CONNECT; putExtra(AeroVpnService.EXTRA_CONFIG, SSHConfig(c.name,c.host,c.port,c.username.orEmpty(),c.password,c.privateKey,c.privateKeyPassphrase,c.payload,c.proxyHost,c.proxyPort,c.proxyType,c.sni,c.tlsEnabled,c.tlsInsecure)) })
            })
        } else Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("AeroVPN • SSH / HTTP Custom", style=MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp)); Button(onClick={editing=VpnConfig(name="SSH profile",protocol="SSH",port=22)}) { Text("New SSH profile") }
            Spacer(Modifier.height(12.dp)); LazyColumn { items(configs) { c -> Card(onClick={editing=c}, modifier=Modifier.fillMaxWidth().padding(vertical=4.dp)) { Column(Modifier.padding(16.dp)) { Text(c.name); Text("${c.host}:${c.port} • ${c.proxyType}") } } } }
        }
    }
}

@Composable private fun SshEditor(initial: VpnConfig, onCancel:()->Unit, onSave:(VpnConfig)->Unit, onConnect:(VpnConfig)->Unit) {
    var c by remember { mutableStateOf(initial) }; var keyMode by remember { mutableStateOf(c.privateKey != null) }
    @Composable fun text(label:String, value:String, set:(String)->Unit) { OutlinedTextField(value,set,label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("SSH profile", style=MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(8.dp))
        text("Name",c.name){c=c.copy(name=it)}; text("Host",c.host){c=c.copy(host=it)}; text("Port",if(c.port==0) "22" else c.port.toString()){c=c.copy(port=it.toIntOrNull()?:0)}
        text("Username",c.username.orEmpty()){c=c.copy(username=it)}
        Row { Text("Private key auth"); Switch(keyMode,{keyMode=it}) }
        if(keyMode) { text("Private key (PEM/OpenSSH)",c.privateKey.orEmpty()){c=c.copy(privateKey=it,password=null)}; text("Key passphrase",c.privateKeyPassphrase.orEmpty()){c=c.copy(privateKeyPassphrase=it)} }
        else text("Password",c.password.orEmpty()){c=c.copy(password=it)}
        text("Payload (use [crlf] or\\r\\n)",c.payload.orEmpty()){c=c.copy(payload=it)}
        text("Proxy host (optional)",c.proxyHost.orEmpty()){c=c.copy(proxyHost=it)}; text("Proxy port",c.proxyPort?.toString().orEmpty()){c=c.copy(proxyPort=it.toIntOrNull())}
        text("Proxy type: NONE / HTTP / SOCKS5",c.proxyType){c=c.copy(proxyType=it.uppercase())}; text("SNI / TLS server name",c.sni.orEmpty()){c=c.copy(sni=it)}
        Row { Text("TLS wrapper"); Switch(c.tlsEnabled,{c=c.copy(tlsEnabled=it)}) }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End) { TextButton(onClick=onCancel){Text("Cancel")}; TextButton(onClick={onSave(c)}){Text("Save")}; Button(onClick={onConnect(c)},enabled=c.host.isNotBlank()&&c.username.orEmpty().isNotBlank()){Text("Connect")} }
    }
}

enum class ConnectionStatus { CONNECTED, CONNECTING, DISCONNECTED, ERROR }
